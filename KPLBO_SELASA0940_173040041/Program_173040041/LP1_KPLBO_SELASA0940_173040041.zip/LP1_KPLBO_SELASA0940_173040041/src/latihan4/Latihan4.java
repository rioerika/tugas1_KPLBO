package latihan4;

import java.util.Scanner;

public class Latihan4 {
	public static void main(String[]args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("N = ");
		int total = 0;
		int n = sc.nextInt();
		
		if (n > 0) {
			for (int i = 0; i < n; i++) {
				 
				total = total + sc.nextInt()  ;
			}
			System.out.println("Total = " + total);
		}else {
			System.out.println("N tidak boleh 0 atau minus");
		}
		
	}
}

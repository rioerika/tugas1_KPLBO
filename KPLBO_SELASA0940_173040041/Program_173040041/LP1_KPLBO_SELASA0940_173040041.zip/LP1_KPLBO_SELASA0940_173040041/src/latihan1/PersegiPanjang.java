package latihan1;

import java.util.Scanner;

public class PersegiPanjang {
	public static void main(String[]args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("panjang : ");
		int panjang = sc.nextInt();
		System.out.print("Luas : ");
		int lebar = sc.nextInt();
		
		int hKeliling = (panjang * 2 )+(lebar * 2);
		int hluas = panjang*lebar;
		
		System.out.println("Luas : " + hluas);
		System.out.println("Keliling : " +hKeliling);
		
	}
}

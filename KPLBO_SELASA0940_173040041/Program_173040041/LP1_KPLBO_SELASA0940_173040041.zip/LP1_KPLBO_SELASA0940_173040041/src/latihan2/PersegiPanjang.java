package latihan2;

import java.util.Scanner;

public class PersegiPanjang {
	static double panjang; 
	static double lebar ;
	
	 public double hitungLuas(double panjang , double lebar) {
		 double hluas = panjang*lebar;
		 return hluas;
	 }
	 
	 public double hitungKeliling(double panjang , double lebar) {
		 double hKeliling = (panjang * 2 )+(lebar * 2);
		 
		 return hKeliling;
	 }
	 
	 void tampil(double panjang , double lebar) {
		System.out.println("panjang : " + panjang);
		System.out.println("Lebar : " + lebar  );
		System.out.println("Luas : " +hitungLuas(panjang, lebar));
		System.out.println("keliling : " + hitungKeliling(panjang , lebar));
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PersegiPanjang p = new PersegiPanjang();
		
		
		System.out.print("Panjang : ");
		panjang =sc.nextDouble();
		System.out.print("Lebar : ");
		lebar = sc.nextDouble();
		
		
		p.tampil(panjang , lebar);
		
		
	}
	
	

}

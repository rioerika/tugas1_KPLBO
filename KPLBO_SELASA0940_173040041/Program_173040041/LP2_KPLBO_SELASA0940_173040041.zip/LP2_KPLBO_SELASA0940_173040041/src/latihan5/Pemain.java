package latihan5;

public class Pemain {
	private String nama;
	private int nomerPunggung;
	
	
	public String getNama() {
		return nama;
	}
	
	public void setNama(String nama) {
		this.nama = nama;
	}
	
	public int getNomerPunggung() {
		return nomerPunggung;
	}
	
	public void setNomerPunggung(int nomerPunggung) {
		this.nomerPunggung = nomerPunggung;
	}
	
	public String toString() {
		return nomerPunggung + ", " + nama;
	}
	
	public Pemain() {
		nama = "";
		nomerPunggung = 0;
	}
	
	public Pemain(String nama) {
		this.nama = nama;
	}
	
	public Pemain(String nama , int nomerPunggung) {
		this.nama = nama;
		this.nomerPunggung = nomerPunggung;
	}
	

	
}

package latihan5;

public class PemainMain {

	public static void main(String[] args) {
		Pemain pemain1 = new Pemain("I made", 1);
		System.out.println(pemain1);
		
		Pemain pemain2 = new Pemain("Vujovic", 6);
		System.out.println(pemain2);
		
		Pemain pemain3 = new Pemain("Atep", 7);
		System.out.println(pemain3);
		
		Pemain pemain4 = new Pemain("febry", 22);
		System.out.println(pemain4);
		
		
	}

}

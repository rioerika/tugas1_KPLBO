package latihan3;

public class Pemain {
	private String nama;
	private int nomerPunggung;
	
	
	public String getNama() {
		return nama;
	}
	
	public void setNama(String nama) {
		this.nama = nama;
	}
	
	public int getNomerPunggung() {
		return nomerPunggung;
	}
	
	public void setNomerPunggung(int nomerPunggung) {
		this.nomerPunggung = nomerPunggung;
	}
	
	public String toString() {
		return nama + nomerPunggung;
	}
	
	public Pemain() {
		nama = "";
		nomerPunggung = 0;
	}
	

	
}

package latihan3;

public class PemainMain {

	public static void main(String[] args) {
		Pemain pemain = new Pemain();
		pemain.setNama("M.Salah");
		pemain.setNomerPunggung(10);
		System.out.println(pemain);
		
	}

}

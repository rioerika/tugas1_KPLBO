package latihan2;

public class PemainMain {

	public static void main(String[] args) {
		Pemain pemain = new Pemain();
		pemain.setNama("M.Salah");
		pemain.setNomerPunggung(11);
		System.out.println(pemain);
		
	}

}

package latihan4;

public class PemainMain {

	public static void main(String[] args) {
		Pemain pemain1 = new Pemain();
		pemain1.setNama("M.Salah");
		pemain1.setNomerPunggung(10);
		System.out.println(pemain1);
		
		Pemain pemain2 = new Pemain("Rio erika");
		pemain2.setNomerPunggung(20);
		System.out.println(pemain2);
		
		Pemain pemain3 = new Pemain("Atep", 7);
		System.out.println(pemain3);
		
	}

}

package latihan6;

public class Pemain {
	private String nama;
	private int nomerPunggung;
	private int gajiPerMinggu;
	
	
	public String getNama() {
		return nama;
	}
	
	public void setNama(String nama) {
		this.nama = nama;
	}
	
	public int getNomerPunggung() {
		return nomerPunggung;
	}
	
	public void setNomerPunggung(int nomerPunggung) {
		this.nomerPunggung = nomerPunggung;
	}
	
	public int getGajiPerMinggu() {
		return gajiPerMinggu;
	}
	
	public void setGajiPerMinggu(int gaji) {
		this.gajiPerMinggu = gaji;
	}
	
	public int getGajiPerBulan(int gaji) {
		return gaji * 4;
	}
	
	public String toString() {
		return nomerPunggung + ", " + nama + "\n" + 
				"gaji per minggu : " + gajiPerMinggu + "\n" +
				"gaji per Bulan : " + getGajiPerBulan(gajiPerMinggu);
	}
	
	public Pemain() {
		nama = "";
		nomerPunggung = 0;
	}
	
	public Pemain(String nama) {
		this.nama = nama;
	}
	
	public Pemain(String nama , int nomerPunggung) {
		this.nama = nama;
		this.nomerPunggung = nomerPunggung;
	}
	
	public Pemain(String nama , int nomerPunggung, int gaji) {
		this.nama = nama;
		this.nomerPunggung = nomerPunggung;
		this.gajiPerMinggu =  gaji;
	}
	
	

	
}
